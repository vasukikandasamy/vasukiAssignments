package oopsConceptsTasks;
class Calculator
{
	int add(int a, int b)
	{
		return a+b;
	}
	double add(double a, double b)
	{
		return a+b;
	}
}

public class MethodOverloadingTask {

	public static void main(String[] args) {
		Calculator obj = new Calculator();
		System.out.println(obj.add(10, 20));
		System.out.println(obj.add(1150, 10020));

	}

}
