package oopsConceptsTasks;
class Account
{
	private String accountHolderName;
	private double balance;
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		if (balance < 0) {
            System.out.println("Warning: Balance cannot be negative!");
        } else {
		this.balance = balance;
	}
}

public void display() {
    System.out.println("Account Holder: " + accountHolderName);
    System.out.println("Balance: " + balance);
}
}
public class EncapsulationTask2 {

	public static void main(String[] args) {
		Account obj = new Account();

        // Setting values using setters
        obj.setAccountHolderName("Vasuki");
        obj.setBalance(50000);

        // Trying to set negative balance
        obj.setBalance(-10);

        // Display details
        obj.display();
	}

	}


