package oopsConceptsTasks;
class Shapes
{
	double length;
	void square()
	{
		length = 5;
		double area = length*length;
		System.out.println("Area of Square is: "+ area);
	}
	void rectangle(double breadth)
	{
		length = 10;
		double area = length*breadth;
		System.out.println("Are of Rectangle is:"+ area);
		
		
	}
	void circle()
	{
		length = 20;
		double area = Math.PI*length*length;
		System.out.println("Area of Circle is:"+ area);
	}
}
public class JavaProgramTask1 {

	public static void main(String[] args) {
		Shapes obj = new Shapes();
		obj.square();
		obj.rectangle(5);
		obj.circle();

	}

}
