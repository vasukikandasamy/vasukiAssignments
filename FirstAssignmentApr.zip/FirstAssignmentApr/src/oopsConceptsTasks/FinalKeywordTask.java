package oopsConceptsTasks;
class Bank
{
	final String IFSC = "HDFC0000445";
			final void showIFSC()
			{
				System.out.println("IFSC code is: "+ IFSC);
			}
}
class HDFCBank extends Bank
{
	void showIFSC() // cannot call the final method
	{
		System.out.println("Override is impossible in the final method");
	}
}

public class FinalKeywordTask {

	public static void main(String[] args) {
		Bank obj = new Bank();
		obj.showIFSC();
		HDFCBank obj1 = new HDFCBank();
		obj1.showIFSC();

	}

}
