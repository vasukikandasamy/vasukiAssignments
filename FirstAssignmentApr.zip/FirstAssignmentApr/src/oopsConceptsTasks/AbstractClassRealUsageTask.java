package oopsConceptsTasks;
abstract class Employees
{
	abstract void calculateSalary();
	void employeeDetails()
	{
		System.out.println("Employee details are displaying");
	}
	
}
class FullTimeEmployee extends Employees
{
	void calculateSalary()
	{
		double TotalSalary = 100000;
		double Allowance = 1000;
		double GrossSalary = TotalSalary - Allowance;
		System.out.println("Salary is: "+ GrossSalary);
	}
	
}
class PartTimeEmployee extends Employees
{
	void calculateSalary()
	{
		double TotalSalary = 100000;
		double PartTimeSalary = TotalSalary/2;
		double PF = 3800;
		double Allowance = 15000;
		double TakeHomeSalary = PartTimeSalary - PF - Allowance;
		System.out.println("Take Home salary is: "+TakeHomeSalary);
	}
}


public class AbstractClassRealUsageTask {

	public static void main(String[] args) {
		Employees obj = new FullTimeEmployee();
		obj.employeeDetails();
		obj.calculateSalary();
		Employees obj1 = new PartTimeEmployee();
		obj1.calculateSalary();

	}

}
