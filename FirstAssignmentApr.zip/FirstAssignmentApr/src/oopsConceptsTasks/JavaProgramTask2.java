package oopsConceptsTasks;
class School
{
	String name;
	School(String n)
	{
		this.name=n;
		System.out.println("The name of School "+name);
	}
	void display()
	{
		System.out.println("This School is based out of Kolkata");
	}
}

public class JavaProgramTask2 {

	public static void main(String[] args) {
		School obj = new School("Global School");
		obj.display();
		

	}

}
