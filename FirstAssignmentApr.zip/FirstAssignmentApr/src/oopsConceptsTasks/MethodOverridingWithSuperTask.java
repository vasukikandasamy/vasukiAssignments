package oopsConceptsTasks;
class Hospital 
{
	void emergencyService()
	{
		System.out.println("Emergency service method in Hospital class is displaying");
	}
}
class CityHospital extends Hospital
{
	void emergencyService()
	{
		super.emergencyService();
		
		System.out.println("Emergency service method in CityHospital class is displaying");
	}
}

public class MethodOverridingWithSuperTask {

	public static void main(String[] args) {
		CityHospital obj = new CityHospital();
		obj.emergencyService();

	}

}
