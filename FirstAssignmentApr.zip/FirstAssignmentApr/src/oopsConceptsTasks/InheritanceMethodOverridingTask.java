package oopsConceptsTasks;
class Vechicle
{
	void fuelType()
	{
		System.out.println("Runs on fuel");
	}
}
class ElectricCar extends Vechicle
{
	void fuelType()
	{
		System.out.println("Runs on electricity");
	}
	
}

public class InheritanceMethodOverridingTask {

	public static void main(String[] args) {
		Vechicle obj=new Vechicle();
		obj.fuelType();
		ElectricCar obj1=new ElectricCar();
		obj1.fuelType();

	}

}
