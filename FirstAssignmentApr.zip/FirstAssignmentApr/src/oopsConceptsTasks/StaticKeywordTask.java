package oopsConceptsTasks;
class Student1
{
	static String collegeName = "Nandha Engineering College";
	String name;
	int rollNo;

Student1(String name, int rollNo) {
    this.name = name;
    this.rollNo = rollNo;
}

void display() {
    System.out.println("Name: " + name);
    System.out.println("Roll No: " + rollNo);
    System.out.println("College: " + collegeName);
}
}

public class StaticKeywordTask {

	public static void main(String[] args) {
		Student1 s1 = new Student1("Vasuki", 1);
        s1.display();

        Student1 s2 = new Student1("Sugumar", 2);
        s2.display();

        Student1 s3 = new Student1("Pavan", 3);
        s2.display();

        Student1.collegeName = "Kongu Engineering College";

        System.out.println("After changing college name:\n");

        s1.display();
        s2.display();
        s3.display();

	}

}
