package oopsConceptsTasks;
class Shape {
    void area() {
        System.out.println("Area is print");
    }
}

class Rectangle extends Shape {
    void area() {
        int length = 10;
        int breadth = 5;
        System.out.println("Area of Rectangle is: " + (length * breadth));
    }
}

class Circle extends Shape {
    void area() {
        double radius = 7;
        double pi = 3.14;
        double Circlearea = pi* radius * radius;
        System.out.println("Area of Circle is: " + Circlearea);
    }
}


public class PolymorphismDynamicBindingTask1 {

	public static void main(String[] args) {
		Shape ref = new Rectangle();
		ref.area();
		Shape ref1 = new Circle();
		ref1.area();
		
	}

}
