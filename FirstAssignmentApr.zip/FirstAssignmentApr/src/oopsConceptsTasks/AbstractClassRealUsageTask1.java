package oopsConceptsTasks;
abstract class Employees1 {

String name;

// Constructor
Employees1(String name) {
    this.name = name;
}

// Abstract method
abstract void calculateSalary();

// Concrete method
void employeeDetails() {
    System.out.println("Employee Name: " + name);
}
}

//Full-time employee
class FullTimeEmployee1 extends Employees1 {

double monthlySalary;

FullTimeEmployee1(String name, double salary) {
    super(name);
    this.monthlySalary = salary;
}

// Implementing abstract method
void calculateSalary() {
    System.out.println("Full-Time Salary: " + monthlySalary +"\n");
}
}

//Part-time employee
class PartTimeEmployee1 extends Employees1 {

int hoursWorked;
double hourlyRate;

PartTimeEmployee1(String name, int hours, double rate) {
    super(name);
    this.hoursWorked = hours;
    this.hourlyRate = rate;
}

// Implementing abstract method
void calculateSalary() {
    double salary = hoursWorked * hourlyRate;
    System.out.println("Part-Time Salary: " + salary);
}
}


public class AbstractClassRealUsageTask1 {

	public static void main(String[] args) {
		Employees1 obj = new FullTimeEmployee1("Vasuki", 65000);
		obj.employeeDetails();
		obj.calculateSalary();
		Employees1 obj1 = new PartTimeEmployee1("Pavan", 4, 1000);
		obj1.employeeDetails();
		obj1.calculateSalary();

	}

}
