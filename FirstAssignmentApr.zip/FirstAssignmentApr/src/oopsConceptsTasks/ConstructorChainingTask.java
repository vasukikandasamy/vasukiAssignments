package oopsConceptsTasks;
class Mall
{
	Mall()
	{
		System.out.println("Welcome to the Mall");
	}
	Mall(String mallName)
	{
		this();
		System.out.println("The Mall Name is: "+mallName);
	}
}

public class ConstructorChainingTask {

	public static void main(String[] args) {
		Mall obj = new Mall("FunMall");

	}

}
