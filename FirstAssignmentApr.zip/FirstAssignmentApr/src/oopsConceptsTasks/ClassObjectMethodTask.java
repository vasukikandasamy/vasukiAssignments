package oopsConceptsTasks;
class Library
{
	String libraryName = "Public Library";
	Library()
	{
		System.out.println("Welcome to the Library!");
	
	}
	void showLocation()
	{
		System.out.println("This library is located in Mumbai");
	}
}
public class ClassObjectMethodTask {

	public static void main(String[] args) {
		Library obj = new Library();
		obj.showLocation();

	}

}
