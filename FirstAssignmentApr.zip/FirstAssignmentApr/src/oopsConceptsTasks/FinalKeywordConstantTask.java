package oopsConceptsTasks;
class GovernmentRules
{
	final int MAX_WORKING_HOURS = 8;
	void display()
	{
		System.out.println("The MAX working hours:"+MAX_WORKING_HOURS +"\n");
	}
}

public class FinalKeywordConstantTask {

	public static void main(String[] args) {
		GovernmentRules obj = new GovernmentRules();
		obj.display();
		
//		System.out.println("Max working hours is: "+obj.MAX_WORKING_HOURS);
		obj.MAX_WORKING_HOURS = 16; // Compile time Error

		

	}

}
