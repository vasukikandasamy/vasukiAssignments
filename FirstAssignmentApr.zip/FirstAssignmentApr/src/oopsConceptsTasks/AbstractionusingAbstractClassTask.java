package oopsConceptsTasks;
abstract class Animal
{
	abstract void sound();
}
class Dog extends Animal
{
	void sound()
	{
		System.out.println("Dog barks");
	}
}
class Cat extends Animal
{
	void sound()
	{
		System.out.println("Cat bites");
	}
}

public class AbstractionusingAbstractClassTask {

	public static void main(String[] args) {
		Animal obj = new Dog();
		obj.sound();
		Animal obj1 = new Cat();
		obj1.sound();
		

	}

}
