package oopsConceptsTasks;
class Camera
{
	void capture()
	{
		System.out.println("Capture the Nature");
	}
}
class DSLCamera extends Camera
{
	void capture()
	{
		System.out.println("DSL Camera override the capture");
	}
}

public class RuntimeUpcastingPloymorphismTask {

	public static void main(String[] args) {
		Camera ref = new DSLCamera();
		ref.capture();

	}

}
