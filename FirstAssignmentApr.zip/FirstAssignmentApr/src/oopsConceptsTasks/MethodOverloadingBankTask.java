package oopsConceptsTasks;
class LoanCalculator
{
	void calculateLoan(int amount)
	{
	      
	        System.out.println("Total personal loan amount: " + amount);
	        
	    }

	    // Overloaded method with loan amount and custom interest rate
	    void calculateLoan(int amount, double interestRate) {
	    	System.out.println("Total car loan amount: " + amount);
	        System.out.println("Interest Rate: " + interestRate + "%");
	        double interest = amount * (interestRate / 100);
	        System.out.println("Total Amount to Pay with interest: " + (amount + interest));
	    }
}

public class MethodOverloadingBankTask {

	public static void main(String[] args) {
		LoanCalculator obj = new LoanCalculator();
		obj.calculateLoan(100000);
		obj.calculateLoan(500000, 1.5);

	}

}
