package oopsConceptsTasks;
class Device
{
	void start()
	{
		System.out.println("start method is display");
	}
}
class Mobile extends Device
{
	void calling()
	{
		System.out.println("calling method is display");
	}
}
class SmartPhone extends Mobile
{
	void internet()
	{
		System.out.println("internet method is display");
	}
}

public class InheritanceMultiLevelTask {

	public static void main(String[] args) {
		SmartPhone obj = new SmartPhone();
		obj.start();
		obj.calling();
		obj.internet();

	}

}
