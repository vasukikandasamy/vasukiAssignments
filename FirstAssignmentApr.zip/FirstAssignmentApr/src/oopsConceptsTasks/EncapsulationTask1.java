package oopsConceptsTasks;
class Employee
{
	private int empId;
	private String empName;
	private double salary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void displayDetails() {
        System.out.println("Employee ID: " + empId);
        System.out.println("Employee Name: " + empName);
        System.out.println("Salary: " + salary);
	}
}

public class EncapsulationTask1 {

	public static void main(String[] args) {
		Employee obj = new Employee();
		obj.setEmpId(123);
		obj.setEmpName("Vasuki");
		obj.setSalary(65000);
		obj.displayDetails();

	}

}
