package oopsConceptsTasks;
class School1
{
	String name;
	String address;
	int strength;
	School1(String n, String addrs)
	{
		this.name=n;
		this.address=addrs;
	}
	School1(String n, String addrs, int Stren)
	{
		this.name=n;
		this.address=addrs;
		this.strength=Stren;
	}
	void display()
	{
		System.out.println("Name is: "+ name);
		System.out.println("Address is: "+address);
		System.out.println("Strength is: "+strength);
	}
}
public class JavaProgramTask3 {

	public static void main(String[] args) {
		School1 obj = new School1("Global School", "Tamilnadu");
		obj.display();
		School1 obj1 = new School1("Global School", "Tamilnadu", 60);
		obj1.display();
		
		
		

	}

}
