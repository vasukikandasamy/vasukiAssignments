package oopsConceptsTasks;
interface Payment
{
	void makePayment();
}
class UPI implements Payment
{
	public void makePayment()
	{
		System.out.println("UPI is working properly");
	}
}
class CreditCard implements Payment
{
	public void makePayment()
	{
		System.out.println("Credit Card is working properly");
	}
}

public class InterfaceTask {

	public static void main(String[] args) {
		Payment ref = new UPI();
		ref.makePayment();
		Payment ref1 = new CreditCard();
		ref1.makePayment();
	

	}

}
