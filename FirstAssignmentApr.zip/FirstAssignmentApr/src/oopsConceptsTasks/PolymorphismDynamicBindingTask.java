package oopsConceptsTasks;
//Not a dynamic binding
class Shape1
{
    double area() 
    {
        System.out.println("Area");
        return 0;
    }
}

class Rectangle1 extends Shape1
{
    double area(int length, int breadth)
    {
        
        return length*breadth;
    }
}

class Circle1 extends Shape1 
{
    double area(int radius) 
    {
        radius = 7;
        double pi=3.14;
        double circlearea = pi * radius * radius;
        return circlearea;
    }
}

public class PolymorphismDynamicBindingTask {

	public static void main(String[] args) {

        Rectangle1 ref = new Rectangle1();
        System.out.println("Area of Rectangle is: " + ref.area(12, 15));
        
        Circle1 ref1 = new Circle1();
        System.out.println("Area of Circle is: " + ref1.area(5));

	}

}
