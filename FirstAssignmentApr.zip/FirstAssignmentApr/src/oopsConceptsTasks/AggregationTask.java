package oopsConceptsTasks;
class Engine 
{
    
    void engineInfo() 
    {
        System.out.println("Engine is working properly");
    }
}

class Car
{
    
    String carName;
    Engine engine; // Aggregation (HAS-A relationship)

    Car(String carName, Engine engine) 
    {
        this.carName = carName;
        this.engine = engine;
    }
    void display() 
    {
        System.out.println("Car Name is: " + carName);
        engine.engineInfo(); // Using Engine object
    }
}


public class AggregationTask {

	public static void main(String[] args) {
		Engine obj = new Engine();
		Car obj1 = new Car("Maruti Suzuki", obj);
		obj1.display();

	}

}
