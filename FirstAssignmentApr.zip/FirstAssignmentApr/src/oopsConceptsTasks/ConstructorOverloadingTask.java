package oopsConceptsTasks;
class Product
{
	int productId;
	String productName;
	double price;
	Product()
	{
		System.out.println("Product Created \n");
	}
	Product(int id, String name, double pr)
	{
        productId = id;
        productName = name;
        price = pr;
	}
	void displayProduct()
	{
		System.out.println("Product Id is: " + productId);
		System.out.println("Product Name is: " + productName);
		System.out.println("price is: " + price);
	}
}

public class ConstructorOverloadingTask {

	public static void main(String[] args) {
Product obj1 = new Product();
obj1.displayProduct();

System.out.println();

Product obj = new Product(123, "Samsung", 20000);
obj.displayProduct();
	}

}
