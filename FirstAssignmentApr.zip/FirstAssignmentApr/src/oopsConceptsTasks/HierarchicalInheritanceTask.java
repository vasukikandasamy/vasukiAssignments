package oopsConceptsTasks;
class Course
{
	void courseInfo()
	{
		System.out.println("courseInfo is displaying");
	}
}
class Science extends Course
{
    void departmentScience()
    {
    	System.out.println("Science department details displaying");
    }
}
class Commerce extends Course
{
	void departmentCommerce()
	{
		System.out.println("Commerce department details displaying");
	}
}
class Arts extends Course
{
	void artsCollege()
	{
		System.out.println("Arts college details displaying");
	}
}

public class HierarchicalInheritanceTask {

	public static void main(String[] args) {
		Arts obj = new Arts();
		obj.artsCollege();
		obj.courseInfo();
		Science obj1 = new Science();
		obj1.departmentScience();
		Commerce obj2 = new Commerce();
		obj2.departmentCommerce();

	}

}
