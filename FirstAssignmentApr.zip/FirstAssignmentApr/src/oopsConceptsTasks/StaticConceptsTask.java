package oopsConceptsTasks;
class University
{
	static String country = "India";
	String universityName;
	University(String name)
	{
		this.universityName = name;
	}
	void display()
	{
		System.out.println("University Name is: "+universityName);
		System.out.println("University located Country Name is:"+ country);
	}
	void change() // We can use this method to change the country name
	{
		country = "UK";
	}
	
}

public class StaticConceptsTask {

	public static void main(String[] args) {
		University obj = new University("Anna University");
		obj.display();
		University obj1 = new University("Annamalai University");
		obj1.display();
		//University.country = "UK"; /** we can use this to change the country method **/
		obj.change();
		obj.display();
		obj1.display();
		
		
	}

}
