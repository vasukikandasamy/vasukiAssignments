package oopsConceptsTasks;
interface Transport
{
	void booking();
	
}
class Bus implements Transport
{
	public void booking()
	{
		System.out.println("Bus is booked under Transport department");
	}
	
}
class Flight implements Transport
{
	public void booking()
	{
		System.out.println("Flight is booked under Transport department");
	}
}
public class InterfaceWithMultipleImplementationTask {

	public static void main(String[] args) {
		Transport ref = new Bus();
		ref.booking();
		Transport ref1 = new Flight();
		ref1.booking();
		

	}

}
