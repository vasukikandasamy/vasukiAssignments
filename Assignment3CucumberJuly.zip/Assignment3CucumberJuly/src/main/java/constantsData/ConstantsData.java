package constantsData;

public class ConstantsData {
	
	public static final String PROP_FILE_PATH = "src/main/java/Global.properties";
	public static final String EXCEL_PATH = "src/main/java/testData/TestData1.xlsx";
	public static final String CUSID_EXCEL_PATH="src/main/java/testData/TestData.xlsx";

}
