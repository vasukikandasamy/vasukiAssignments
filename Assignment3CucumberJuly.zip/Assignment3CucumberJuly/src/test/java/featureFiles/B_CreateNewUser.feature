Feature: New Customer Creation

  Background: 
    Given user enter the login page
    When User enters login credentials
      | UserID     | Password |
      | mngr664140 | zUseqah  |
    And User clicks on Login button
    Then User should be logged in successfully

  Scenario: Validate new user creation in Guru99 using DataTable
    And user clicks on the new customer link
    When the user enters customer details
      | CustomerName | Gender | DateOfBirth | Address          | City | State | PIN     | MobileNumber | Email                | Password |
      | Vasuki k     | Female | 12-07-1996  | 12 Cheran Street | CBE  | TN    | 1000019 |   9876543210 | vasukik12091@test.com | Pass@123 |
    And the user clicks the Register button
    Then the customer should be registered successfully
    And capture the Customer ID and store it in Excel
    And user clicks on the New Account link
    When the user enters new account details
      | AccountType | InitialDeposit |
      | Savings     |           5000 |
    And the user clicks the Create Account button
    And the account should be created successfully
    Then capture the Account ID and store it in Excel
    When the user clicks on Edit Account
    And the user enters the account number
    And the user clicks on Submit button
    When the user edits the customer address
      | Address           |
      | Erode, Tamil Nadu |
    And the user clicks the Update button
