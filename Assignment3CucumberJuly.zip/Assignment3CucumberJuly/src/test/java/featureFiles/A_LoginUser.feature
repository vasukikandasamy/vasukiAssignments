Feature: Guru99 login feature

  Background: 
    Given user enter the login page

  Scenario: To validate the Login functionality with valid credentials
    When User enters login credentials
      | UserID | Password |
      | mngr664140 | zUseqah  |
    And User clicks on Login button
    Then User should be logged in successfully
