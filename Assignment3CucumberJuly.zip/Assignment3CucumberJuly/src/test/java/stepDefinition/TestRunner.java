package stepDefinition;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
(
		features="src/test/java/FeatureFiles/", 
		glue= {"stepDefinition"},
		
		plugin= {"pretty","html:target/HTMLReports/index.html",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"} //for Report--html// Usually we will generate spark extend report
		)

public class TestRunner {

}
