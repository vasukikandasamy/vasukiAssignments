package stepDefinition;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageFactoryClasses.CreateUserPage;
import pageFactoryClasses.EditAccountPage;
import pageFactoryClasses.LoginPageClass;
import pageFactoryClasses.NewAccountPage;
import utilities.BaseClassDriverInitialization;
import utilities.FetchDataFromExcel;

public class StepDefinition extends BaseClassDriverInitialization {
	
	WebDriver driver = BaseClassDriverInitialization.initializeDriver();//initialize the driver
	LoginPageClass obj = new LoginPageClass(driver);//create an object for LoginPageClass
	CreateUserPage obj1 = new CreateUserPage(driver);
	NewAccountPage obj2 = new NewAccountPage(driver);
	EditAccountPage obj3 = new EditAccountPage(driver);
	

	@Given("user enter the login page")
	public void user_enter_the_login_page() throws IOException {
	    driver.get(FetchDataFromExcel.getURL(1, 0));
	}

	@When("User enters login credentials")
	public void user_enters_login_credentials(io.cucumber.datatable.DataTable dataTable) {
		List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);

        String userId = data.get(0).get("UserID");
        String password = data.get(0).get("Password");
        
        obj.enterUserName(userId);
        obj.enterPassword(password);   

	}

	@When("User clicks on Login button")
	public void user_clicks_on_login_button() {
		obj.clickLogin();
        System.out.println("LoggedIn successfully");

	    	}

	@Then("User should be logged in successfully")
	public void user_should_be_logged_in_successfully() throws Exception {
		String title=	BaseClassDriverInitialization.getTitle();
		 if(title.contains("HomePage"))
		 {
			 System.out.println("Test case passed");
		 }
		 else
		 {
			 throw new Exception("Login not validated");
		 }
	    System.out.println("Got the title successfully");
	}
	
	@Given("user clicks on the new customer link")
	public void user_clicks_on_the_new_customer_link() {
	    obj1.clickOnNewCustomer();
	    System.out.println("Clicked on New customer successfully");
	}

	@When("the user enters customer details")
	public void the_user_enters_customer_details(io.cucumber.datatable.DataTable dataTable) {
		List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);

	    Map<String, String> customer = data.get(0);
	    obj1.enterUserName(customer.get("CustomerName"));
	    obj1.selectGender(customer.get("Gender"));
	    obj1.enterDOB(customer.get("DateOfBirth"));
	    obj1.enterAddress(customer.get("Address"));
	    obj1.enterCity(customer.get("City"));
	    obj1.enterState(customer.get("State"));
	    obj1.enterPin(customer.get("PIN"));
	    obj1.enterMobile(customer.get("MobileNumber"));
	    obj1.enterEmail(customer.get("Email"));
	    obj1.enterPassword(customer.get("Password"));
	    System.out.println("Entered the customer details successfully");



	    
	}

	@When("the user clicks the Register button")
	public void the_user_clicks_the_register_button() {
		obj1.clickOnSubmit();
		System.out.println("Registered successfully+");
	    	}

	@Then("the customer should be registered successfully")
	public void the_customer_should_be_registered_successfully() {
		obj1.getSuccessMessage();	
		System.out.println("Got the success message");
		    }
	@Then("capture the Customer ID and store it in Excel")
	public void capture_the_customer_id_and_store_it_in_excel() throws IOException {

		String customerID = obj1.getCustomerID();

	    System.out.println("Customer ID : " + customerID);

	    FetchDataFromExcel.writeCustomerID(customerID);
	    System.out.println("Captured the Customer ID successfully");
	
	    	}
	@Then("user clicks on the New Account link")
	public void user_clicks_on_the_new_account_link() {
	    obj2.clickNewAccountLink();
	    System.out.println("Clicked on New Account Link successfully");
	}

	@When("the user enters new account details")
	public void the_user_enters_new_account_details(io.cucumber.datatable.DataTable dataTable) throws IOException {
		List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);

	    Map<String, String> account = data.get(0);

	    String customerID = FetchDataFromExcel.getCustomerID();

	    obj2.enterCustomerId(customerID);
	    System.out.println("Passed the Customer ID successfully");

	    obj2.selectAccountType(account.get("AccountType"));

	    obj2.enterInitialDeposit(account.get("InitialDeposit"));
	    
	    System.out.println("Entered the details successfully");
	}
	

	@When("the user clicks the Create Account button")
	public void the_user_clicks_the_create_account_button() {
		obj2.clickSubmit();
		System.out.println("Created an Account successfully");
	    
	}

	@When("the account should be created successfully")
	public void the_account_should_be_created_successfully() throws IOException {
	    String message = obj2.getSuccessMessage();

	    Assert.assertEquals(message, "Account Generated Successfully!!!");

	    String accountID = obj2.getAccountId();

	    System.out.println("Account ID : " + accountID);

	    FetchDataFromExcel.writeAccountID(accountID);
	    System.out.println("Get the AccountID and stored into an Excel");

	    
	}

	@Then("capture the Account ID and store it in Excel")
	public void capture_the_account_id_and_store_it_in_excel() {
	    System.out.println("Stored successfully");
	}
	
	@When("the user clicks on Edit Account")
	public void the_user_clicks_on_edit_account() {
		obj3.clickEditAccountLink();
		System.out.println("Clicked on Edit Account successfully");
		
	    	}

	@When("the user enters the account number")
	public void the_user_enters_the_account_number() throws IOException {
	    String customerID = FetchDataFromExcel.getCustomerID();

		obj3.enterCustomerId(customerID);
		System.out.println("Fetched the customer ID successfully");
	    }

	@When("the user clicks on Submit button")
	public void the_user_clicks_on_submit_button() {
		obj3.clickSubmit();
		System.out.println("Clicked on Submit to edit the details successfully");
	   	}
	@When("the user edits the customer address")
	public void the_user_edits_the_customer_address(DataTable dataTable) {

	    List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);

	    String address = data.get(0).get("Address");

	    obj3.editAddress(address);
	    System.out.println("Get the address from the data table");
	}

	@When("the user clicks the Update button")
	public void the_user_clicks_the_update_button() {

	    obj3.clickSubmit1();
	    System.out.println("Clicked on submit to edit the details");
	    
	    System.out.println("Successfully done the Assignment");
	}




}