package pageFactoryClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class NewAccountPage {
WebDriver driver;
	
	public NewAccountPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//*[text()='New Account']")
	WebElement newAccLink;
	
	
	@FindBy(xpath="//*[@name='cusid']")
	WebElement Cust_Id;
	
	@FindBy(xpath="//*[@name='selaccount']")
	WebElement SelectAccount;
	
	@FindBy(xpath="//*[@name='inideposit']")
	WebElement Deposit;
	
	@FindBy(xpath="//*[@name='button2']")
	WebElement Submit;
	
	@FindBy(xpath="//p[@class='heading3']")
	WebElement SuccessMsg;
	
	@FindBy(xpath="//td[text()='Account ID']/following-sibling::td") 
	WebElement AccID;
	
	public void clickNewAccountLink() {

		newAccLink.click();
	}
	
	public void enterCustomerId(String customerId) {

		Cust_Id.sendKeys(customerId);
	}
	
	public void selectAccountType(String accountType) {

        Select select = new Select(SelectAccount);
	    select.selectByVisibleText(accountType);
	}
	
	public void enterInitialDeposit(String amount) {

		Deposit.sendKeys(amount);
	}
	public void clickSubmit() {

		Submit.click();
	}
	
	public String getSuccessMessage() {

	    return SuccessMsg.getText();
	}
	
	public String getAccountId() {

	    return AccID.getText();
	}


}
