package pageFactoryClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageClass {
	WebDriver driver;
	//constructor---common creation for all
	public LoginPageClass(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="[name='uid']")
	WebElement userID;
	
	@FindBy(css="[name='password']")
	WebElement pwd;
	
	@FindBy(css="[name='btnLogin']")
	WebElement btnLogin;
	
	public void enterUserName(String uname)
	{
		userID.sendKeys(uname);
	}
	
	public void enterPassword(String password)
	{
		pwd.sendKeys(password);
	}
	
	public void clickLogin()
	{
		btnLogin.click();
	}
	

}
