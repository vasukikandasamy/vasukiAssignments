package pageFactoryClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EditAccountPage {
	
WebDriver driver;
	
	public EditAccountPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	
	@FindBy(xpath = "//*[text()='Edit Customer']")
	WebElement editAccountLink;

	@FindBy(name = "cusid")
	WebElement customerId;

	@FindBy(name = "AccSubmit")
	WebElement submit;
	
	@FindBy(name = "addr")
	WebElement address;

	@FindBy(name = "sub")
	WebElement submit1;

	public void clickEditAccountLink() {
		editAccountLink.click();
	}

	public void enterCustomerId(String custId) {
	    customerId.clear();
	    customerId.sendKeys(custId);
	}

	public void clickSubmit() {
	    submit.click();
	}
	
	public void editAddress(String newAddress) {
	    address.clear();
	    address.sendKeys(newAddress);
	}

	public void clickSubmit1() {
	    submit1.click();

}
}
