package utilities;

import java.io.FileReader;
import java.util.Properties;
import java.io.IOException;

import constantsData.ConstantsData;

public class FetchDataFromProperty {
	public static Properties getDataProperty() throws IOException
	{
	FileReader reader = new FileReader(ConstantsData.PROP_FILE_PATH);
	Properties prop = new Properties();
	prop.load(reader);
	return prop;
	
	
	}

}
