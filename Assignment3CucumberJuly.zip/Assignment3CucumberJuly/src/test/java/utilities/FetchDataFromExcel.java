package utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import constantsData.ConstantsData;

public class FetchDataFromExcel {

	public static String getURL(int x, int y) throws IOException {
		FileInputStream fs = new FileInputStream(ConstantsData.EXCEL_PATH);
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
		XSSFSheet sheet = workbook.getSheetAt(0);
		XSSFCell val = sheet.getRow(x).getCell(y);
		String URL = val.toString();
		return URL;
	}

	// Write Customer ID to Excel
	/**
	public static void writeCustomerID(String customerID, int rowNum, int cellNum) throws IOException {

		FileInputStream fis = new FileInputStream(ConstantsData.CUSID_EXCEL_PATH);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		XSSFSheet sheet = workbook.getSheet("Sheet1");

		XSSFRow row = sheet.getRow(rowNum);

		if (row == null) {
			row = sheet.createRow(rowNum);
		}

		Cell cell = row.createCell(cellNum);
		cell.setCellValue(customerID);

		fis.close();

		FileOutputStream fos = new FileOutputStream(ConstantsData.CUSID_EXCEL_PATH);
		workbook.write(fos);

		fos.close();
		workbook.close();

		System.out.println("Customer ID saved successfully.");
	}
	*/
    public static String getData(int rowNum, int cellNum) throws IOException {

        FileInputStream fis = new FileInputStream(ConstantsData.CUSID_EXCEL_PATH);
        XSSFWorkbook workbook = new XSSFWorkbook(fis);

        XSSFSheet sheet = workbook.getSheet("Sheet1");

        String value = sheet.getRow(rowNum).getCell(cellNum).toString();

        workbook.close();
        fis.close();

        return value;
    }

    // Write Data
    public static void writeData(int rowNum, int cellNum, String value) throws IOException {

        FileInputStream fis = new FileInputStream(ConstantsData.CUSID_EXCEL_PATH);
        XSSFWorkbook workbook = new XSSFWorkbook(fis);

        XSSFSheet sheet = workbook.getSheet("Sheet1");

        if (sheet == null) {
            sheet = workbook.createSheet("Sheet1");
        }

        XSSFRow row = sheet.getRow(rowNum);

        if (row == null) {
            row = sheet.createRow(rowNum);
        }

        Cell cell = row.getCell(cellNum);

        if (cell == null) {
            cell = row.createCell(cellNum);
        }

        cell.setCellValue(value);

        fis.close();

        FileOutputStream fos = new FileOutputStream(ConstantsData.CUSID_EXCEL_PATH);

        workbook.write(fos);

        fos.close();
        workbook.close();
    }

    // Customer ID
    public static void writeCustomerID(String customerID) throws IOException {
        writeData(3, 0, customerID);
    }

    public static String getCustomerID() throws IOException {
        return getData(3, 0);
    }

    // Account ID
    public static void writeAccountID(String accountID) throws IOException {
        writeData(3, 1, accountID);
    }

    public static String getAccountID() throws IOException {
        return getData(3, 1);
    }

	}

