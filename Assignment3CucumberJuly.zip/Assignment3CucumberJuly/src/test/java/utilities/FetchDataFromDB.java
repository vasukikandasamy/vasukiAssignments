package utilities;

public class FetchDataFromDB {

}
