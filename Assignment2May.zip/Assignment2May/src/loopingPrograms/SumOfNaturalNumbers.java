package loopingPrograms;

import java.util.Scanner;

public class SumOfNaturalNumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number which you want to sum");
		int num = sc.nextInt();
		int sum = 0;
		
		for(int i=1; i<=num; i++)//i=1; 1<=5// i=2;2<=5//i=3;3<=5//i=4;4<=5//i=5;5<=5//i=6;6<=5 --false
		{
			sum = sum+i; //1+2+3+4+5=15
		}
		System.out.println("The sum of the given Natural number is: "+ sum);//15
		sc.close();

	}

}
