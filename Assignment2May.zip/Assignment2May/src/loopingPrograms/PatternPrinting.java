package loopingPrograms;

import java.util.Scanner;

public class PatternPrinting {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();//n=5

		for(int i=1; i<=n; i++) {//i=1,1<=5//i=2,2<=5//i=3,3<=5//i=4,4<=5//i=5,5<=5//i=6,6!<=5-false
			for(int j=1; j<=i; j++)//j=1,1<=1//j=1,1<=2//j=2,2<=2//j=3,3<=2//j=1,1<=3,j=2,2<=3//j=3,3<=3//j=4,4<=3//j=1,1<5//j=2,2<=4//j=3,3<=4//ji=4,4<=4//j=5,5<=4//j=1,1<=5//j=2,2<=5//j=3,3<=5//j=4,4<=5//j=5,5<=5//j=6,6<=5
				{
				System.out.print("*");
				//*
				//**
				//***
				//****
				//*****
			}
			System.out.println();
		}
sc.close();
	}

}
