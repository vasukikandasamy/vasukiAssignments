package loopingPrograms;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a number");
		int num = sc.nextInt();

		int reverse = 0;

		while(num != 0) //1234!=0//123!=0//12!=0//1!=0//0==0--false
		{
			int digit = num % 10;//1234%10=4//123%10=3//12%10=2//1%10=1
			reverse = reverse * 10 + digit;//0*10+4=4//4*10+3=43//43*10+2=432//432*10+1=4321
			num = num / 10;//1234/10=123//123/10=12//12/10=1//1/10=0
			
/*
 * 321%10=1//32%10=2//3%10=3
 * 0*0+1=1//1*10+2=12//12*10+3=123
 * 321/10=32//32/10=3//3/10=0
 */
			
			/*
			 * 123%10=3//12%10=2//1%10=1
			 * 0*0+3=3//3*10+2=32//32*10+1=321
			 * 123/10=12//12/10=1//1/10=0
			 */
		}

		System.out.println("Reversed number is: " + reverse); //4321

		sc.close();

	}

}
