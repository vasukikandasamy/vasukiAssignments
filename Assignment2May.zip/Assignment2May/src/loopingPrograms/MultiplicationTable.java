package loopingPrograms;

import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a number");
		int num = sc.nextInt();//num = 4
		System.out.println("The "+ num+"th table Multiplication is given below for the 10 numbers:");

		for(int i = 1; i <= 10; i++) //i=1,1<=10//i=2,2<=10//i=3,3<=10//i=4,4<=10//i=5,5<=10//i=6,6<=10//i=7,7<=10//i=8,8<=10//i=9,9<=10//i=10,10<=10//i=11,11!<=10-false
		{
			System.out.println(num + " x " + i + " = " + (num * i));// 4x1=4//4x2=8//4x3=12//4x4=16//4x5=20//4x6=24//4x7=28//4x8=32//4x9=36//4x10=40
		}

		sc.close();
	}

	}


