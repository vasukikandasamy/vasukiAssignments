package loopingPrograms;

import java.util.Scanner;

public class CountTheDigits {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a number");
		int num = sc.nextInt(); //98765

		int count = 0;

		while(num != 0) //98765!=0//9876!=0//987!=0//98!=0//9!=0//0==0-false
		{
			num = num / 10;//98765/10=9876//9876/10=987//987/10=98//9//9/10=0
			count++;//1//2//3//4//5
		}

		System.out.println("Number of digits: " + count);//5

		sc.close();

	}

}
