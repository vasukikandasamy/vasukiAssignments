package loopingPrograms;

import java.util.Scanner;

public class EvenOrOddNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int x = sc.nextInt();
		if(x%2==0) //x=4,4%2==0 //if x=3,3%2!=0
		{
			System.out.println("The given number is Even");
		}
		else
		{
			System.out.println("The given number is Odd");
		}
		sc.close();

	}

}
