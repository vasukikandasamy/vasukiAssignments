package loopingPrograms;

import java.util.Scanner;

public class LeapYearOrNot {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the year");
		int year = sc.nextInt();
		
		if(year%4==0 && year%100!=0 || year%400==0)//year=2000,2000%4==0 && 2000%100==0 || 2000%400==0
			
			//year=2001,2001%4!=0 && 2001%100!=0 || 2001%400!=0 - then go to else part
		{
			System.out.println("The given year is a leap year");
		}
		
		else
		{
			System.out.println(year+(" is not a leap year"));
		}
		sc.close();
	}

}
