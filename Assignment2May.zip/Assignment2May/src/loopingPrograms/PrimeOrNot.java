package loopingPrograms;

import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();
		boolean isPrime = true;
		for(int i=2; i<=n/2; i++)//i=2,2<11/2=2<5//i=3,3<11/2=3<5//i=4,4<11/2=4<5//5<11/2=2<5--condition false
		{
			if(n%i==0)//11%2!=0//never enter in this statement, so Prime num
			{
				isPrime = false;
				break;
			}
		}
			System.out.println(isPrime?"Prime Number":"Not A Prime Number");
			sc.close();
		}

	}


