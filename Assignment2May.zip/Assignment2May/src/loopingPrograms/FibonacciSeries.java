package loopingPrograms;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter number of terms");
		int num = sc.nextInt();

		int firstNum = 0;
		int secondNum = 1;

		System.out.print("Fibonacci Series: ");

		for(int i = 1; i <= num; i++)//i=1,1<=6//i=2,2<=6//3<=6
		{
			System.out.print(firstNum + " ");//0//1//1..

			int nextNum = firstNum + secondNum;//0+1=1//1+1=2
			firstNum = secondNum;//0=0//1=1
			secondNum = nextNum;//1=1//1
		}

sc.close();
	}

}
