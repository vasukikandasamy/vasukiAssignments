package loopingPrograms;

import java.util.Scanner;
//Using nestedIfElse Loop

public class LargestOfThreeNumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number A:");
		int a = sc.nextInt();
		System.out.println("Enter the second number B: ");
		int b = sc.nextInt();
		System.out.println("Enter the third number C: ");
		int c = sc.nextInt();
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("A is maximum");
		
			}
			else
			{
				System.out.println("C is maximum");
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println("B is maximum");
			}
			else
			{
				System.out.println("C is maximum");
			}
		}
		
	
	}

}
