package loopingPrograms;

import java.util.Scanner;

public class FactorialNum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = sc.nextInt();
		 int factorial = 1;
		 
		 for(int i=1; i<=num; i++) //i=1,1<=5//i=2,2<=5//i=3,3<=5//i=4,4<=5//i=5,5<=5//6<=5--false
		 {
			 factorial = factorial*i;//1*1=1//1*2=2//2*3=6//6*4=24//24*5=120
		 }
		 System.out.println("Factorial of given "+num+" is: "+factorial);//120
		 sc.close();
		 

	}

}
