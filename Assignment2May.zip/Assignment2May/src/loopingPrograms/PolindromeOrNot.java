package loopingPrograms;

import java.util.Scanner;

public class PolindromeOrNot {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a number");
		int num = sc.nextInt(); //121
		int actNumber = num; //121
		int reverse = 0;

		while(num != 0) //121!=0//12!=0//1!=0//0==0-false
		{
			int digit = num % 10;//121%10=1//12%10=2//1%10=1
			reverse = reverse * 10 + digit;//0*0+1=1//1*10+2=12//12*10+1=121
			num = num/10;//121/10=12//12/10=1//1/10=0
		}

		System.out.println("Reversed number is: " + reverse); 

		
		if(actNumber==reverse)
		{
			System.out.println(reverse+" is a Polindrome");
		}
		else
		{
			System.out.println(reverse+" is not a Polindrome");
		}
		sc.close();

	}

}
