package arrayPrograms;

import java.util.Scanner;

public class ArrayLeftByKposition {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = sc.nextInt();
		int []arr=new int[size];
		System.out.println("Enter the array elements");//{12,45,67,89,78}
		for(int i=0; i<size; i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter K value");
		int k = sc.nextInt();//k=2

		for(int i = 1; i <= k; i++)//i=1,1<=2//i=2,2<=2//i=3,3!<=2---false
		{
			int first = arr[0];//12

			for(int j = 0; j < arr.length - 1; j++)//j=0,0<5-1(0<4)//j=1,1<4//j=2,2<4//j=3,3<4//j=4,4<4
			{
				arr[j] = arr[j + 1];//arr[0]=arr[0+1]===arr[0]=arr[1]//12=45//arr[1]=arr[1+1]==arr[1]=arr[2]=12=67//arr[2]=arr[3]//arr[3]=arr[4]
			}

			arr[arr.length - 1] = first;//arr[5-1]=arr[4]
		}

		System.out.println("Array after left rotation:");

		for(int i = 0; i < arr.length; i++)
		{
			System.out.print(arr[i] + " ");
		}

		sc.close();

	}

}
