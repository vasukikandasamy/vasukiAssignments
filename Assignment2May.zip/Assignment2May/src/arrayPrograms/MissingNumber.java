package arrayPrograms;

import java.util.Scanner;

public class MissingNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the value of N");
		int n = sc.nextInt();

		int arr[] = new int[n - 1];

		System.out.println("Enter " + (n - 1) + " array elements");

		for(int i = 0; i < arr.length; i++)//i=0,0<4//i=1,1<4//i=2,2<4//i=3,3<4//i=4,4<4-false
		{
			arr[i] = sc.nextInt();//1//2//4//5
		}

		int expectedSum = n * (n + 1) / 2;//5*(5+1)/2=5*3=15

		int actualSum = 0;

		for(int i = 0; i < arr.length; i++)//i=0,0<4//i=1,1<4//i=2,2<4//i=3,3<4//i=4,4<4=false
		{
			actualSum = actualSum + arr[i];//0+arr[0]=0+1=1//1+arr[1]=1+2=3//3+arr[2]=3+4=7//7+arr[3]=7+5=12
		}

		int missingNumber = expectedSum - actualSum;//15-12=3

		System.out.println("Missing number is: " + missingNumber); //3

		sc.close();

	}

}
