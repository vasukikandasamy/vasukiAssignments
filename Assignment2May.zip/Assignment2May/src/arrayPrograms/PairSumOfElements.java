package arrayPrograms;

import java.util.Scanner;

public class PairSumOfElements {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter size of array");
		int size = sc.nextInt();//size=5

		int arr[] = new int[size];

		System.out.println("Enter array elements");//{1,2,3,4,5}

		for(int i = 0; i < size; i++)
		{
			arr[i] = sc.nextInt();
		}

		System.out.println("Enter target sum");
		int target = sc.nextInt();//3

		System.out.println("Pairs with sum " + target + " are:");

		for(int i = 0; i < arr.length; i++)//i=0,0<5//i=1,1<5//2<5
		{
			for(int j = i + 1; j < arr.length; j++)//j=1,1<5//j=2,2<5//j=2,2<5......
			{
				if(arr[i] + arr[j] == target)//arr[0]+arr[1]==1+2=3//arr[0]+arr[2]=1+3=4!=3--false//arr[1]+arr[2]=2+3=5==5!=3-false
				{
					System.out.println(arr[i] + " + " + arr[j] + " = " + target);//1+2=3
				}
			}
		}

		sc.close();

	}

}
