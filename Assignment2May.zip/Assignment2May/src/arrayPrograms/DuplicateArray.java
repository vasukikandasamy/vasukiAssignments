package arrayPrograms;

import java.util.Scanner;

public class DuplicateArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the size of array");
		int size = sc.nextInt();

		int arr[] = new int[size];

		System.out.println("Enter array elements"); //{12,13,12}

		for(int i = 0; i < size; i++)
		{
			arr[i] = sc.nextInt();
		}

		System.out.println("Array after removing duplicates:");

		for(int i = 0; i < size; i++) //i=0,0<3//i=1,1<3//i=2,2<3
		{
			boolean isDuplicate = false;

			for(int j = 0; j < i; j++)//j=0,0<0 -false//j=0,0<1//j=0,0<2
			{
				if(arr[i] == arr[j])//a[1]!=a[0]--false//a[2]==a[0]==true and break
				{
					isDuplicate = true;
					break;
				}
			}

			if(!isDuplicate)//
			{
				System.out.print(arr[i] + " ");//12//13
			}
		}

		sc.close();

	}

}
