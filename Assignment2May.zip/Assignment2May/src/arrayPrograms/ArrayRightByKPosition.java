package arrayPrograms;

import java.util.Scanner;

public class ArrayRightByKPosition {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter size of array");
		int size = sc.nextInt();

		int arr[] = new int[size];

		System.out.println("Enter array elements");

		for(int i = 0; i < size; i++)
		{
			arr[i] = sc.nextInt();
		}

		System.out.println("Enter K value");
		int k = sc.nextInt();

		// Right rotation
		for(int i = 1; i <= k; i++)//i=1,1<=2//i=2,2<=2
		{
			int last = arr[arr.length - 1];//arr[5-1=4]

			for(int j = arr.length - 1; j > 0; j--)//j=4,4>0//j=3,3>0//j=2,2>0//j=1,1>0//j=0,0!>0-false
			{
				arr[j] = arr[j - 1];//arr[4]==arr[3]//arr[3]=arr[2]//arr[2]=arr[1]//arr[1]=arr[0]
			}

			arr[0] = last; //arr[0]=arr[4]
		}

		System.out.println("Array after right rotation:");

		for(int i = 0; i < arr.length; i++)
		{
			System.out.print(arr[i] + " ");
		}

		sc.close();

	}

}
