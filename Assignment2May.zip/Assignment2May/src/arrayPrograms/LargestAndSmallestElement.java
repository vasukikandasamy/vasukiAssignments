package arrayPrograms;

import java.util.Scanner;

public class LargestAndSmallestElement {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the size of array");
		int size = sc.nextInt();//5

		int arr[] = new int[size];

		System.out.println("Enter array elements"); //{12,23,34,54,31}

		for(int i = 0; i < size; i++)//i=0,0<5//i=1,1<5//i=2,2<5//i=3,3<5//i=4,4<5//i=5,5<5--false
		{
			arr[i] = sc.nextInt();//12//23//34//54//31
		}

		int largest = arr[0];
		int smallest = arr[0];

		for(int i = 1; i < arr.length; i++)//i=1,1<5
		{
			if(arr[i] > largest)//a[0]>....
			{
				largest = arr[i];
			}

			if(arr[i] < smallest)//a[0]<....
			{
				smallest = arr[i];
			}
		}

		System.out.println("Largest element in the given Array is : " + largest);
		System.out.println("Smallest element in the given Array is : " + smallest);
		sc.close();
	}

	

}
