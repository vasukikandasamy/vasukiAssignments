package arrayPrograms;

import java.util.Scanner;

public class MoveZerosToEnd {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter size of array");
		int size = sc.nextInt();

		int arr[] = new int[size];

		System.out.println("Enter array elements"); //{1,0,3,0,4}

		for(int i = 0; i < size; i++)
		{
			arr[i] = sc.nextInt();
		}

		int index = 0;

		// Move non-zero elements forward
		for(int i = 0; i < arr.length; i++)//i=0,0<5//i=1,1<5//i=2,2<5//i=3,3<5//i=4,4<5//i=5,5<5--false
		{
			if(arr[i] != 0)//arr[0]!=0==1!=0//arr[1]!=0==0!=0-false//arr[2]!=0==3!=0
			{
				arr[index] = arr[i];//arr[0]=arr[0]--1//arr[1]==arr[2]--3//...4
				index++;//1//2
			}
		}

		// Fill remaining positions with zeros
		while(index < arr.length)//0<5//1<5...
		{
			arr[index] = 0;//arr[0]=0//arr[1]=0
			index++;//1//2...
		}

		System.out.println("Array after moving zeros to end:");

		for(int i = 0; i < arr.length; i++)
		{
			System.out.print(arr[i] + " ");//1,2,3,0,0
		}

		sc.close();

	}

}
