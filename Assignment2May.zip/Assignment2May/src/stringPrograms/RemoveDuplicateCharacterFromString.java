package stringPrograms;

import java.util.Scanner;

public class RemoveDuplicateCharacterFromString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a string");//pavan
		String str = sc.nextLine();

		String result = "";//pavan

		for(int i = 0; i < str.length(); i++)//i=0,i<5//i=a,a<5//i=2,2<5//i=3,3<5//i=4,4<5//i=5,5<5--false
		{
			char ch = str.charAt(i);//ch=p//ch=a//ch=v//ch=a//ch=n

			// Check if character already exists in result
			if(result.indexOf(ch) == -1)//-1=-1//-1=-1//-1=-1//1!=-1//-1==-1
			{
				result = result + ch;//""+p=p//p+a=pa//pa+v=pav//pav+n//pavn
			}
			
		}

		System.out.println("String after removing duplicates:");
		System.out.println(result);

		sc.close();

	}

}
