package stringPrograms;

import java.util.Scanner;

public class CountOccuranceOfCharacters {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a string:");//Vasuki Kandasamy
		String str = sc.nextLine().toLowerCase();//vasuki kandasamy

		// Convert string into character array
		char[] ch = str.toCharArray();//'v','a','s','u','k','i','','k','a','n','d','a','s','a','m','y'

		System.out.println("Character Occurrences:");

		for (int i = 0; i < ch.length; i++) //i=0,0<16//
		{

			int count = 1;

			// Skip already counted characters
			if (ch[i] == '0') //v//a//
			{
				continue;
			}

			for (int j = i + 1; j < ch.length; j++)
			{

				if (ch[i] == ch[j] && ch[i] != ' ') 
				{

					count++;

					// Mark counted character
					ch[j] = '0';
				}
			}

			// Ignore spaces
			if (ch[i] != ' ')
			{
				System.out.println(ch[i] + " = " + count);//v=1//a=4//s=2//u=1//k=2//i=1//n=1//d=1//m=1//y=1
			}
		}

		sc.close();

	}

}
