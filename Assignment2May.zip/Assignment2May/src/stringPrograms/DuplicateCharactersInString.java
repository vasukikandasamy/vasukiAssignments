package stringPrograms;

import java.util.Scanner;

public class DuplicateCharactersInString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a string"); //natarajan
		String str = sc.nextLine().toLowerCase();

		System.out.println("Duplicate characters are:");
		boolean found = false;


		for(int i = 0; i < str.length(); i++)//i=0,0<9//i=1,1<9
		{
			int count = 0;

			for(int j = 0; j < str.length(); j++)//j=0,0<9//j=1,1<9//j=0,0<9
			{
				if(str.charAt(i) == str.charAt(j) && str.charAt(i) != ' ')//n==n&&n!=''//n==a-false//a==n-false
				{
					count++;//0
				}
			}

			// Print duplicate only once
			if(count > 1)//0>1-false
			{
				boolean alreadyPrinted = false;

				for(int k = 0; k < i; k++)
				{
					if(str.charAt(i) == str.charAt(k))
					{
						alreadyPrinted = true;
						break;
					}
				}
			
				if(!alreadyPrinted)//
				{
					

					System.out.println(str.charAt(i));
				}
				
			}
		}
		if(!found)
		{
			System.out.println("No duplicates found");
		}
			
		
		
		sc.close();

	}

}
